//index.js 
const db = wx.cloud.database()
const _ = db.command
const postsCollection = db.collection('posts')

var app = getApp()
var touchDot = 0//触摸时的原点 
var touchDotY=0
var time = 0// 时间记录，用于滑动时且时间小于1s则执行左右滑动 
var interval = ""// 记录/清理时间记录
Page({
  
  data: {
    // posts: [],
    feed: [],
    feed_length: 0,
    searchValue: '',
    search_res: '',
    list: [],
    page:0,
    count:0,
    i:0
  },

  onLoad: function () {
    wx.cloud.init();
    console.log('onLoad');

  },

  onShow: function () {
      var that = this;
      var content_array = new Array();
      postsCollection.where({
        like_count:_.gte(0)
      }).count().then(res =>{
        console.log(res.total)
        this.setData({
          count: res.total
        })
      })
    setTimeout(function () {
      let i=0
      let count = that.data.count
      console.log('count=%d.',count)
      while(count>20){
        count=count-20
        i=i+20
      }
      console.log('i=%d.',i)
  
      db.collection('posts').skip(i).get().then(res => {
        content_array = res.data;
        that.setData({
          feed: content_array.reverse(),
          i:i
        });
      })
    }, 2000) //延迟2秒
 },

 

/*方案一：跳转到comment
bindItemTap: function () {
   wx.navigateTo({
     url: '../comment/comment'
   })
},*/
/*方案二：跳转到posts*/
bindItemTap: function (event) {
  let str = JSON.stringify(event.currentTarget.dataset.itemValue);
    wx.navigateTo({
      url: '../posts/posts?jsonstr='+str,
    })
},

  //网络请求数据, 实现首页刷新

/////////////手势操作/////////
 touchStart: function (e) {
    touchDot = e.touches[0].pageX // 获取触摸时的原点 
    touchDotY = e.touches[0].pageY
    // 使用js计时器记录时间  
    interval = setInterval(function () {
      time++;
    }, 100);
  },
  // 触摸移动事件 
  touchMove: function (e) {
    var touchMove = e.touches[0].pageX;
    var touchMoveY = e.touches[0].pageY;
    console.log("touchMove:" + touchMove + " touchDot:" + touchDot + " diff:" + (touchMove - touchDot));
    // 向左滑动  
    if (touchMove - touchDot <= -60 && time < 10) {
      wx.switchTab({
        url: '../material/material'
      });
    }
    // 向右滑动 
    if (touchMove - touchDot >= 60 && time < 10) {
      console.log('向右滑动');
      wx.switchTab({
        url: '../index/index'
      });
    }
    //向下滑动
    if (touchMoveY - touchDotY >= 60 && time < 100) {
      console.log('向下滑动');
      wx.cloud.init();
      wx.showNavigationBarLoading();

      var that = this;
      var content_array = new Array();
      postsCollection.where({
        like_count:_.gte(0)
      }).count().then(res =>{
        console.log(res.total)
        this.setData({
          count: res.total
        })
      })
    setTimeout(function () {
      let i=0
      let count = that.data.count
      console.log('count=%d.',count)
      while(count>20){
        count=count-20
        i=i+20
      }
      console.log('i=%d.',i)
  
      db.collection('posts').skip(i).get().then(res => {
        content_array = res.data;
        that.setData({
          feed: content_array.reverse(),
        });
      })
    }, 2000) //延迟2秒

      setTimeout(function () {
        wx.hideNavigationBarLoading()
       }, 1000) //延迟1秒
    }
    if (touchMoveY - touchDotY >= 40 && time < 100) {

    }
  },
  // 触摸结束事件 
  touchEnd: function (e) {
    clearInterval(interval); // 清除setInterval 
    time = 0;
  },

  searchValueInput: function (e) {
    var value = e.detail.value;
    this.setData({
      searchValue: value,
    });
  },
 

  start_search_db: function (e) {
    var keyword = this.data.searchValue;
    wx.navigateTo({
      url: '../search/search?searchValue=' + keyword,
    });
  },

  //发帖
  onPostClick: function (e) {
    var type = "new";
    wx.navigateTo({
      url: '../release/release?type='+ type,
      success: function (res) { },
      fail: function (res) { },
      complete: function (res) { },
    })
  },
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    console.log("向下滑动")
    wx.cloud.init();
    wx.showNavigationBarLoading();

    var that = this;
    var content_array = new Array();
    postsCollection.where({
      like_count:_.gte(0)
    }).count().then(res =>{
      console.log(res.total)
      this.setData({
        count: res.total
      })
    })
  setTimeout(function () {
    let i=that.data.i
    let count = that.data.count
    console.log('count=%d.',count)
    while(count>20){
      count=count-20
      i=i+20
    }
    console.log('i=%d.',i)

    db.collection('posts').skip(i).get().then(res => {
      content_array = res.data;
      that.setData({
        feed: content_array.reverse(),
        i:i
      });
    })
  }, 2000) //延迟2秒

    setTimeout(function () {
      wx.hideNavigationBarLoading()
     }, 1000) //延迟1秒
  },
  onReachBottom: function () {
    console.log("向上滑动");
    wx.cloud.init();
    let page=this.data.i-20
    console.log('page=%d.',page)
    postsCollection.skip(page).get().then(res => {
      let content_array = res.data;
      let old_array = this.data.feed.reverse()
      this.setData({
        feed: content_array.concat(old_array).reverse(),
        page:page
      });
    });
  }
})
