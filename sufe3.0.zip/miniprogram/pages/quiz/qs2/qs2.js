var app = getApp()
Page({

  A() {
    wx.redirectTo({
      url: '../qs3/qs3',
      complete: function (res) {
        console.log("第三个问题");
      }
    })
  },

  B() {
    app.globalData.accuracy = app.globalData.accuracy + 1
    wx.redirectTo({
      url: '../qs3/qs3',
      complete: function (res) {
        console.log("第三个问题");
      }
    })
  },

  C() {
    wx.redirectTo({
      url: '../qs3/qs3',
      complete: function (res) {
        console.log("第三个问题");
      }
    })
  },

  D() {
    wx.redirectTo({
      url: '../qs3/qs3',
      complete: function (res) {
        console.log("第三个问题");
      }
    })
  }
})