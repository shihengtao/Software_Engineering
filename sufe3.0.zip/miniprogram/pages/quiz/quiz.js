// pages/quiz/quiz.js
Page({
begin(){
  wx.redirectTo({
    url: 'qs1/qs1',
    complete: function (res) {
      console.log("开始答题");
    }
  })
}
})