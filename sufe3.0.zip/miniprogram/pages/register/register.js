var app = getApp();
const db = wx.cloud.database();
const admin = db.collection('adminlist');

Page({
  data: {
    username: '', //用户注册的账号
    password1: '', //用户注册的密码
    password2: '', //用户确认的密码
  },
  usernumInput: function (res) {
    var username = this.data.username;
    this.setData({
      username: res.detail.value
    })
    console.log("用户账号信息输入")
  }, //将用户账号框信息传输给页面数据 

  passward1Input: function (res) {
    var password1 = this.password1;
    this.setData({
      password1: res.detail.value
    })
    console.log("用户注册密码输入")
  }, //将用户注册密码框信息传输给页面数据

  passward2Input: function (res) {
    var password2 = this.data.password2;
    this.setData({
      password2: res.detail.value
    })
    console.log("用户确认密码输入")
  }, //将用户第二次密码信息传输给页面数据

  registerClick1: function (event) {
    var username = this.data.username;
    var password2 = this.data.password2;
    var password1 = this.data.password1;
    if (username == '' || password2 == '' || password1 == '')
      wx.showToast({
        title: '请输入信息',
        icon: 'none',
        duration: 2000
      })
    else {
      
      if (password1 == password2) {
        if(username.length > 11 || username.length < 1){
          wx.showToast({
            title: '账号长度在1-11位',
            icon: 'none',
            duration: 2000
            })
        }
        else if (password1.length > 15 || password1.length < 6)
          wx.showToast({
            title: '密码长度在6-15位',
            icon: 'none',
            duration: 2000
          })
        else {
          let flag = false //是否存在 true为存在
          admin.get({ //查询用户是否已经注册
            success: (res) => {
              let admins = res.data; //获取到的对象数组数据
              for (let i = 0; i < admins.length; i++) { //遍历数据库对象集合
                if (username == admins[i].username) { //用户名存在
                  flag = true;
                }
              }
              if (flag == true) { //已注册
                wx.showToast({
                  title: '账号已注册！',
                  icon: 'none',
                  duration: 2500
                })
              } else { //未注册
                admin.add({ //添加数据
                  data: {
                    username: username,
                    password: password1
                  }
                }).then(res => {
                  console.log('注册成功！')
                  wx.showToast({
                    title: '注册成功！',
                    icon: 'success',
                    duration: 3000
                  })
                  wx.redirectTo({
                    url: '/pages/login/login',
                  })
                })
              }
            }
          })
        }
      } else wx.showToast({
        title: '密码不一致',
        icon: 'none',
        duration: 2000
      })
    }
  }, //将用户注册的账户和密码传输给服务器

  registerClick2: function () {
    wx.redirectTo({
      url: '../login/login',
      complete: function (res) {
        console.log("返回登录页面");
      }
    })
  }, //返回登录页面 
})