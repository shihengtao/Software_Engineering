var app = getApp();
const db = wx.cloud.database();
const admin = db.collection('adminlist');

Page({
/**
   * 生命周期函数--监听页面显示 
   */
  onShow: function() {
   // wx.hideHomeButton()
  },

  data: {
    username:'',//用户登录账号
    password:'',//用户登录密码
    userid:'',//返回来的用户id
  },

  usernameInput: function (res) {
    var username=this.data.username;
    this.setData({
      username: res.detail.value
    })
    console.log('账户输入');
  },//将用户账号输入框的数据传入到页面数据

  passwordInput: function (res) {
    var password = this.data.password;
    this.setData({
      password: res.detail.value
    })
    console.log('密码输入');
  },//将用户密码输入框的数据传入页面数据

  loginbtnClick:function(){
    console.log("11111111111111111111111111111")
    var username = this.data.username;
    var password = this.data.password
    if (username == '' || password == '' ){
      wx.showToast({
        title: '输入信息',
        icon: 'none',
        duration: 1000
      })
    }
    else{
      console.log("22222222222222222222222222222222")
      admin.get({
        success:(res)=>{
          let user = res.data;
         console.log(res.data);
          for (let i = 0; i < user.length; i++) {  //遍历数据库对象集合
            if (username == user[i].username) { //用户名存在
              if (password != user[i].password) {  //判断密码是否正确
              console.log("33333333333333333333333333333")
                wx.showToast({
                  title: '密码错误！！',
                  icon: 'none',
                  duration: 2500
                })
              } else {
                console.log('登录成功！')
                wx.showToast({
                  title: '登录成功！！',
                  icon: 'success',
                  duration: 2500
                })
                wx.switchTab({   //跳转首页
                  url: '/pages/index/index',  //登录完成后跳转主页
                })
              }
              break;
            }else{   //不存在
              if(i == user.length-1){
                console.log(i);
              wx.showToast({
                title: '用户名不存在！',
                icon: 'none',
                duration: 2500
              })
            }
            }
          }
        }
      })
    }
  },//用户登录按钮点击，进行服务器登录，返回用户账号和用户id   

  registerClick: function () {
    wx.navigateTo({
      // url: '../register/register',
      url: '../quiz/quiz',
      complete: function (res) {
        console.log('注册按钮，跳转到注册页面')
      }
    })
  },//注册按钮，跳转到注册页面

/*   returnback:function(){
    wx.switchTab({
      url: '../index/index',
      complete: function (res) {
        console.log('返回按钮，跳转到首页')
      }
    })
  },//返回按钮，跳转到首页 */
 
})