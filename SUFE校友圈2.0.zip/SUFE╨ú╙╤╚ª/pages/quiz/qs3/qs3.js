var app = getApp()
Page({

  A() {
    wx.redirectTo({
      url: '../qs4/qs4',
      complete: function (res) {
        console.log("第四个问题");
      }
    })
  },

  B() {
    wx.redirectTo({
      url: '../qs4/qs4',
      complete: function (res) {
        console.log("第四个问题");
      }
    })
  },

  C() {
    app.globalData.accuracy = app.globalData.accuracy + 1
    wx.redirectTo({
      url: '../qs4/qs4',
      complete: function (res) {
        console.log("第四个问题");
      }
    })
  },

  D() {
    wx.redirectTo({
      url: '../qs4/qs4',
      complete: function (res) {
        console.log("第四个问题");
      }
    })
  }
})