var app = getApp()
Page({

  A() {
    app.globalData.accuracy = app.globalData.accuracy + 1
    console.log(app.globalData.accuracy + "+++++++++++++++++++++++++++")
    if (app.globalData.accuracy == 4){
      wx.showToast({
        title: '恭喜你答题成功',
        icon: 'none',
        duration: 2000
      })
      wx.redirectTo({
        url: '../../register/register',
        complete: function (res) {
          console.log("第四个问题");
        }
      })
    }else{
      wx.showToast({
        title: '对不起您有题目回答错误',
        icon: 'none',
        duration: 2000
      })
      wx.redirectTo({
        url: '../../login/login',
        complete: function (res) {
          console.log("返回登录界面");
        }
      })
    }
    
  },

  B() {
    wx.showToast({
      title: '对不起您有题目回答错误',
      icon: 'none',
      duration: 2000
    })
    wx.redirectTo({
      url: '../../login/login',
      complete: function (res) {
        console.log("返回登录界面");
      }
    })
  },

  C() {
    wx.showToast({
      title: '对不起您有题目回答错误',
      icon: 'none',
      duration: 2000
    })
    wx.redirectTo({
      url: '../../login/login',
      complete: function (res) {
        console.log("返回登录界面");
      }
    })
  },

  D() {
    wx.showToast({
      title: '对不起您有题目回答错误',
      icon: 'none',
      duration: 2000
    })
    wx.redirectTo({
      url: '../../login/login',
      complete: function (res) {
        console.log("返回登录界面");
      }
    })
  }
})