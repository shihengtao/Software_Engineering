// pages/quiz/qs1/qs1.js
var app = getApp()
Page({

A(){
  app.globalData.accuracy = 1
  console.log(app.globalData.accuracy+"+++++++++++++++++++++++++++")
  wx.redirectTo({
    url: '../qs2/qs2',
    complete: function (res) {
      console.log("第二个问题");
    }
  })
},

B(){
  wx.redirectTo({
    url: '../qs2/qs2',
    complete: function (res) {
      console.log("第二个问题");
    }
  })
},

C(){
  wx.redirectTo({
    url: '../qs2/qs2',
    complete: function (res) {
      console.log("第二个问题");
    }
  })
},

D(){
  wx.redirectTo({
    url: '../qs2/qs2',
    complete: function (res) {
      console.log("第二个问题");
    }
  })
}
})